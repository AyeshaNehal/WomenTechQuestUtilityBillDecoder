import streamlit as st
import pandas as pd
import json
import os
import subprocess

st.set_page_config(layout="wide", page_title="Utility Bill Decoder")
st.title("The Utility Bill Decoder Demo")

st.sidebar.header("Configuration")
bills_folder = st.sidebar.text_input("Bills Folder", "train/bills")
templates_folder = st.sidebar.text_input("Templates Folder", "tests/fixtures/templates")
output_folder = st.sidebar.text_input("Output Folder", "output_test")

if not os.path.exists(bills_folder):
    st.sidebar.error(f"Bills folder not found: {bills_folder}")
    st.stop()

images = sorted([f for f in os.listdir(bills_folder) if f.lower().endswith(('.png', '.jpg', '.jpeg'))])
if not images:
    st.sidebar.error("No images found in bills folder.")
    st.stop()

selected_img = st.sidebar.selectbox("Select Bill", images)
selected_bill_id = os.path.splitext(selected_img)[0]

col1, col2 = st.columns(2)

with col1:
    st.subheader(f"Bill Image: {selected_img}")
    st.image(os.path.join(bills_folder, selected_img), use_container_width=True)

with col2:
    tab1, tab2 = st.tabs(["Level 1", "Level 2"])
    
    l1_path = os.path.join(output_folder, "level1.csv")
    l2_path = os.path.join(output_folder, "level2.csv")
    
    l1_df = pd.read_csv(l1_path) if os.path.exists(l1_path) else None
    l2_df = pd.read_csv(l2_path) if os.path.exists(l2_path) else None

    with tab1:
        st.subheader("Extracted Level 1 Data")
        if l1_df is not None:
            row = l1_df[l1_df['bill_id'] == selected_bill_id]
            if not row.empty:
                json_data = json.loads(row.iloc[0]['json'])
                
                # Render scalar fields as a table
                scalars = {k: str(v) if v is not None else "null" for k, v in json_data.items() if k not in ['charges', 'taxes']}
                st.table(pd.Series(scalars, name='Value'))
                
                c_col, t_col = st.columns(2)
                with c_col:
                    st.markdown("**Charges**")
                    if json_data.get('charges'):
                        st.dataframe(pd.DataFrame(json_data['charges']), use_container_width=True)
                    else:
                        st.write("No charges")
                with t_col:
                    st.markdown("**Taxes**")
                    if json_data.get('taxes'):
                        st.dataframe(pd.DataFrame(json_data['taxes']), use_container_width=True)
                    else:
                        st.write("No taxes")
                        
                with st.expander("Show raw JSON"):
                    st.json(json_data)
            else:
                st.warning("No Level 1 data found for this bill.")
        else:
            st.warning("Level 1 CSV not found.")

    with tab2:
        st.subheader("Level 2 QA")
        if l2_df is not None:
            rows = l2_df[l2_df['bill_id'] == selected_bill_id]
            if not rows.empty:
                questions = rows['question'].tolist()
                sel_q = st.selectbox("Select a question:", questions)
                ans = rows[rows['question'] == sel_q].iloc[0]['answer']
                st.info(ans)
            else:
                st.warning("No Level 2 data found for this bill.")
        else:
            st.warning("Level 2 CSV not found.")

st.divider()

st.subheader("Pipeline Actions")
if st.button("Generate CSVs"):
    with st.spinner("Running pipeline (using cache)..."):
        env = os.environ.copy()
        env["PYTHONPATH"] = "."
        cmd = ["python", "source/main.py", "--bills", bills_folder, "--templates", templates_folder, "--out", output_folder]
        subprocess.run(cmd, env=env, capture_output=True, text=True)
    
    if os.path.exists(l1_path) and os.path.exists(l2_path):
        l1_df_new = pd.read_csv(l1_path)
        l2_df_new = pd.read_csv(l2_path)
        
        st.write(f"**Level 1 Rows:** {len(l1_df_new)} | **Level 2 Rows:** {len(l2_df_new)}")
        
        st.write("Level 1 Preview:")
        st.dataframe(l1_df_new.head(), use_container_width=True)
        
        st.write("Level 2 Preview:")
        st.dataframe(l2_df_new.head(), use_container_width=True)
        
        # Validation
        valid = True
        req_keys = ["provider", "tariff", "sanctioned_load_kw", "bill_month", "reading_date", 
                    "issue_date", "due_date", "previous_reading", "current_reading", 
                    "units_consumed", "charges", "total_charges", "taxes", "total_taxes", 
                    "current_bill", "arrears", "payable_within_due_date", "payable_after_due_date"]
        
        for _, r in l1_df_new.iterrows():
            if pd.isna(r['json']) or not r['json'].strip():
                valid = False
                continue
            try:
                d = json.loads(r['json'])
                if any(k not in d for k in req_keys): valid = False
            except:
                valid = False
                
        if l2_df_new['answer'].isnull().any() or (l2_df_new['answer'].str.strip() == "").any():
            valid = False
            
        if valid:
            st.success("✅ Validation Passed: Every Level 1 JSON has all schema fields and no Level 2 answer is empty.")
        else:
            st.error("❌ Validation Failed: Missing schema fields or empty answers detected.")
    else:
        st.error("Pipeline failed to generate CSV files.")
